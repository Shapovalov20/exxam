#!/bin/sh

uname -a > satrt.log
df -h >> satrt.log